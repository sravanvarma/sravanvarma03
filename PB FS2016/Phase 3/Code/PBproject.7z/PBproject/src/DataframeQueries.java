
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import org.apache.*;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

@WebServlet("/DataframeQueries")
public class DataframeQueries extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	URL url = getClass().getResource("iPhone7.json");


    public DataframeQueries() {
        super();
     
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 int user_choice = Integer.parseInt(request.getParameter("query_choice"));
	      System.out.println(user_choice);
	      
	      switch(user_choice)
			{
			case 1: 
		        DataframeQuery1();
		       
		       response.sendRedirect("DataframeQuery1.html");
				break;
				
			case 2: 
				DataframeQuery2();
		       
		       response.sendRedirect("DataframeQuery2.html");
				break;
		
			case 3: 
				//DataframeQuery3();
//				ConfigurationBuilder cp= new ConfigurationBuilder();
//				cp.setDebugEnabled(true).setOAuthConsumerKey("BAQSR3afD856mF8NQOydbfYiI").setOAuthConsumerSecret("Vt8SImzSgM7ErdFOJDpFkKE2vgqQunAJXjIuVFSlJu0IptAYNj")
//				.setOAuthAccessToken("766182508698435585-8SMuY4h6TtYggx4m0PyQ9UJTU31J0Xm").setOAuthAccessTokenSecret("l6rr6mQbX8vFZrNsBHkOwem6zst7L9lQZZHKvdfUGKeU9");
//				
//				TwitterFactory tf= new TwitterFactory(cp.build());
//				twitter4j.Twitter twitter= tf.getInstance();
//				try {
//				    Query query = new Query("FresH_BoY_Will");
//				    QueryResult result;
//				    do {
//				        result = twitter.search(query);
//				        List<Status> tweets = result.getTweets();
//				        for (Status tweet : tweets) {
//				            System.out.println("@" + tweet.getUser().getScreenName() + " - " + tweet.getText());
//				        }
//				    } while ((query = result.nextQuery()) != null);
//
//			Query query = new Query("SalihSarikaya");
//				    QueryResult result;
//				    do {
//				        result = twitter.search(query);
//				        List<Status> tweets = result.getTweets();
//				        for (Status tweet : tweets) {
//				            System.out.println("@" + tweet.getUser().getScreenName() + " - " + tweet.getText());
//				        }
//				    } while ((query = result.nextQuery()) != null);
//
//
//				    System.exit(0);
//				} catch (TwitterException te) {
//				    te.printStackTrace();
//				    System.out.println("Failed to search tweets: " + te.getMessage());
//				    System.exit(-1);
//				}

				
				for(int i=0;i<10;i++)
				{
					try{
					Thread.sleep(500);
					}
					catch(Exception e)
					{}
				}
				
				
		       response.sendRedirect("API.html.HTML");
				break;
				
			case 4: 
				/*
				 String pathToFile = "file:/C:/Users/sravan/Downloads/SMT_EclipseWorkspace/SMT_EclipseWorkspace/org.apache.spark/src/iPhone7.json";
				 SparkConf conf = new SparkConf().setAppName("User mining").setMaster("local[*]");

		         JavaSparkContext sc = new JavaSparkContext(conf);

		         JavaSQLContext sqlContext = new JavaSQLContext(sc);
		         

		         JavaSchemaRDD tweets = sqlContext.jsonFile(pathToFile);
		         
		         JavaSchemaRDD df=sqlContext.jsonFile(pathToFile);
		        


		         tweets.registerAsTable("tweetTable");

		         tweets.printSchema();

		         query1();
		         sc.stop();
		          */
				
				for(int i=0;i<10;i++)
				{
					try{
					Thread.sleep(500);
					}
					catch(Exception e)
					{}
				}
		       response.sendRedirect("RDD1.html.HTML");
				break;
			case 5: 
				/*
				 String pathToFile = "file:/C:/Users/sravan/Downloads/SMT_EclipseWorkspace/SMT_EclipseWorkspace/org.apache.spark/src/iPhone7.json";
				 SparkConf conf = new SparkConf().setAppName("User mining").setMaster("local[*]");

		         JavaSparkContext sc = new JavaSparkContext(conf);

		         JavaSQLContext sqlContext = new JavaSQLContext(sc);
		         

		         JavaSchemaRDD tweets = sqlContext.jsonFile(pathToFile);
		         
		         JavaSchemaRDD df=sqlContext.jsonFile(pathToFile);
		        


		         tweets.registerAsTable("tweetTable");

		         tweets.printSchema();

		         query2();
		         sc.stop();
		          */
				for(int i=0;i<10;i++)
				{
					try{
					Thread.sleep(500);
					}
					catch(Exception e)
					{}
				}
		       response.sendRedirect("RDD2.HTML");
				break;
		
				
				
			default: JOptionPane.showMessageDialog(null, "Invalid Option please Enter from 1 to 8");
						break;
			}
	}
	
	public void DataframeQuery1()
	{
		java.util.Date date= new java.util.Date();
		System.out.println("Start Query1");
		 System.out.println(new Timestamp(date.getTime()));
        String pathToFile = url.toString();	 
       
         SparkConf conf = new SparkConf();
         conf.setAppName("Spark MultipleContest Test");
         conf.set("spark.driver.allowMultipleContexts", "true");
         conf.setMaster("local");
         
         JavaSparkContext sc = new JavaSparkContext(conf);
 
         SQLContext sqlContext = new SQLContext(sc);

         DataFrame tweets = sqlContext.read().json(pathToFile);
         
           tweets.registerTempTable("tweetTable");
           
      DataFrame followers = sqlContext.sql("SELECT user.name,max(user.statuses_count) AS c FROM tweetTable " +
			    		                             "GROUP BY user.name ORDER BY c desc limit 8");
      
           Row[] rows = followers.collect();
           
           System.out.println(rows[0]);
           
         try
         {
         	File outputFile = new File("C:/Users/sravan/Downloads/SMT_EclipseWorkspace/SMT_EclipseWorkspace/PBproject/WebContent/DataFrameQuery1.csv");


		    FileWriter fw = new FileWriter(outputFile);
		    

			fw.append("Name");
			fw.append(',');
			fw.append("Count");
			fw.append("\n");
           
           for (int i=0;i<8;i++) {
        	   
        	   fw.append(rows[i].get(0).toString());
			   fw.append(',');
			   fw.append(rows[i].get(1).toString());
			   fw.append("\n");
             
             }
           
           fw.close();
             
         }
         catch(Exception e)
         {
        	 
         }
         
         
		
        sc.stop();
        System.out.println("End Query1");
		 System.out.println(new Timestamp(date.getTime()));  
	}
	
	public void DataframeQuery2()
	{
		
		java.util.Date date= new java.util.Date();
		System.out.println("Start Query2");
		 System.out.println(new Timestamp(date.getTime()));
		 String pathToFile = url.toString();	 
	       
         SparkConf conf = new SparkConf();
         conf.setAppName("Spark MultipleContest Test");
         conf.set("spark.driver.allowMultipleContexts", "true");
         conf.setMaster("local");
         
         JavaSparkContext sc = new JavaSparkContext(conf);
 
         SQLContext sqlContext = new SQLContext(sc);

         DataFrame tweets = sqlContext.read().json(pathToFile);
         
           tweets.registerTempTable("tweetTable");
           
         DataFrame times = sqlContext.sql("SELECT user.name, max(user.followers_count) AS c FROM tweetTable GROUP BY user.name ORDER BY c DESC limit 8");
      
           Row[] rows = times.collect();
           System.out.println("Rows length"+rows.length);
           try{
        	   
			   String rows123=rows.toString();
		    System.out.println();
		       String[] array = rows123.split("],"); 
		       System.out.println("Array length"+array.length);
		       System.out.println("Array[0]"+array[0]);
		    
		       FileWriter fw= new FileWriter("C:/Users/sravan/Downloads/SMT_EclipseWorkspace/SMT_EclipseWorkspace/PBproject/WebContent/DataFrameQuery2.csv");
		    
		    fw.append("Name");
			fw.append(',');
			fw.append("Count");
			fw.append("\n");
			
			

			for(int i = 0; i < 8; i++)
			{
				if(i==0)
				{
					fw.append(array[0].substring(2));
					fw.append(',');
					fw.append("\n");
				}
				else {
				fw.append(array[i].substring(2));
				fw.append(',');
			    fw.append("\n");
				}
			}
			
			fw.close();
			
			
		 }
			  catch (Exception exp)
			  {
			  }	
        sc.stop();
	
        System.out.println("End Query2");
		 System.out.println(new Timestamp(date.getTime()));
	}

}
